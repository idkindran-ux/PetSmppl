package com.zebrawings.pets;

import net.kyori.adventure.text.format.NamedTextColor;

public enum Rarity {
    COMMON("Common", 60, 20, NamedTextColor.GREEN, "<green>"),
    UNCOMMON("Uncommon", 25, 25, NamedTextColor.DARK_GREEN, "<dark_green>"),
    RARE("Rare", 10, 32, NamedTextColor.YELLOW, "<yellow>"),
    VERY_RARE("Very Rare", 4, 40, NamedTextColor.RED, "<red>"),
    ULTRA_RARE("Ultra Rare", 1, 50, NamedTextColor.GOLD, "<gradient:red:yellow>"),
    ADMIN("Admin", 0, 50, NamedTextColor.AQUA, "<aqua>");

    public final String label;
    public final int weight;
    public final int hearts;
    public final NamedTextColor color;
    public final String mini;

    Rarity(String label, int weight, int hearts, NamedTextColor color, String mini) {
        this.label = label;
        this.weight = weight;
        this.hearts = hearts;
        this.color = color;
        this.mini = mini;
    }
}
