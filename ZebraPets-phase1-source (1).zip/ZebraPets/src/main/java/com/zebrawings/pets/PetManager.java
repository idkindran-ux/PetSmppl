package com.zebrawings.pets;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.TextDisplay;
import org.bukkit.util.Transformation;
import org.bukkit.entity.Player;
import org.bukkit.entity.Wolf;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class PetManager {
    private final ZebraPets plugin;
    private final File file;
    private final YamlConfiguration data;
    private final Map<UUID, UUID> active = new HashMap<>();
    public final NamespacedKey keyOwner;
    public final NamespacedKey keyToken;

    public PetManager(ZebraPets plugin) {
        this.plugin = plugin;
        this.keyOwner = new NamespacedKey(plugin, "pet_owner");
        this.keyToken = new NamespacedKey(plugin, "revive_token");
        this.file = new File(plugin.getDataFolder(), "data.yml");
        plugin.getDataFolder().mkdirs();
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    public void save() {
        try { data.save(file); } catch (IOException e) { plugin.getLogger().warning("Save failed: " + e.getMessage()); }
    }

    public PetType getPet(UUID owner) {
        String id = data.getString(owner + ".pet");
        return id == null ? null : PetRegistry.byId(id);
    }

    public boolean isDead(UUID owner) { return data.getBoolean(owner + ".dead"); }

    public void setPet(UUID owner, PetType type) {
        data.set(owner + ".pet", type.id());
        data.set(owner + ".dead", false);
        save();
    }

    public void markDead(UUID owner) {
        data.set(owner + ".dead", true);
        data.set(owner + ".token", true);
        active.remove(owner);
        save();
    }

    public void revive(Player p) {
        data.set(p.getUniqueId() + ".dead", false);
        save();
        spawn(p);
    }

    /** Gives a random pet on first join, then spawns it. */
    public void ensureAndSpawn(Player p) {
        UUID id = p.getUniqueId();
        if (getPet(id) == null) {
            PetType t = PetRegistry.random();
            setPet(id, t);
            p.sendMessage(Component.text("You got a ", NamedTextColor.YELLOW)
                    .append(Component.text(t.name(), t.rarity().color, TextDecoration.BOLD))
                    .append(Component.text(" (" + t.rarity().label + ")! You can't change it.", NamedTextColor.YELLOW)));
        }
        if (data.getBoolean(id + ".token")) giveToken(p);
        spawn(p);
    }

    public void spawn(Player p) {
        UUID id = p.getUniqueId();
        despawn(id);
        PetType t = getPet(id);
        if (t == null || isDead(id)) return;
        double hp = t.rarity().hearts * 2.0;
        Wolf pet = p.getWorld().spawn(p.getLocation(), Wolf.class, w -> {
            w.setOwner(p);
            w.setPersistent(false);
            w.setCustomNameVisible(false);
            w.customName(Component.text(t.name() + " | " + p.getName(), t.rarity().color));
            AttributeInstance max = w.getAttribute(Attribute.MAX_HEALTH);
            if (max != null) max.setBaseValue(hp);
            w.setHealth(hp);
            w.getPersistentDataContainer().set(keyOwner, PersistentDataType.STRING, id.toString());
        });
        active.put(id, pet.getUniqueId());
        ensureLabels(pet, t, p.getName());
    }


    /** Two floating lines above the pet: pet name (rarity colour) and a smaller white owner name. */
    public void ensureLabels(Wolf wolf, PetType t, String ownerName) {
        if (wolf.getPassengers().size() == 2) return;
        for (Entity e : new ArrayList<>(wolf.getPassengers())) e.remove();
        Component petLine = MiniMessage.miniMessage().deserialize(t.rarity().mini + t.name());
        Component ownerLine = Component.text(ownerName, NamedTextColor.WHITE);
        wolf.addPassenger(makeLabel(wolf, petLine, 0.75f, 0.55f));
        wolf.addPassenger(makeLabel(wolf, ownerLine, 0.45f, 0.30f));
    }

    private TextDisplay makeLabel(Wolf wolf, Component text, float scale, float height) {
        return wolf.getWorld().spawn(wolf.getLocation(), TextDisplay.class, d -> {
            d.text(text);
            d.setBillboard(Display.Billboard.CENTER);
            d.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            d.setShadowed(true);
            d.setPersistent(false);
            d.setTransformation(new Transformation(new Vector3f(0f, height, 0f), new AxisAngle4f(),
                    new Vector3f(scale, scale, scale), new AxisAngle4f()));
        });
    }

    public void startLabelTask() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Map.Entry<UUID, UUID> en : new ArrayList<>(active.entrySet())) {
                Entity e = Bukkit.getEntity(en.getValue());
                Player owner = Bukkit.getPlayer(en.getKey());
                PetType t = getPet(en.getKey());
                if (e instanceof Wolf w && owner != null && t != null) ensureLabels(w, t, owner.getName());
            }
        }, 20L, 10L);
    }

    public void despawn(UUID owner) {
        UUID eid = active.remove(owner);
        if (eid == null) return;
        Entity e = Bukkit.getEntity(eid);
        if (e != null) {
            for (Entity pass : new ArrayList<>(e.getPassengers())) pass.remove();
            e.remove();
        }
    }

    public void despawnAll() {
        for (UUID owner : new ArrayList<>(active.keySet())) despawn(owner);
    }

    public void giveToken(Player p) {
        ItemStack item = new ItemStack(Material.NETHER_STAR);
        item.editMeta(m -> {
            m.displayName(Component.text("Revive Token", NamedTextColor.GOLD, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
            m.lore(List.of(Component.text("Right-click the revival point at spawn", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false)));
            m.getPersistentDataContainer().set(keyToken, PersistentDataType.STRING, p.getUniqueId().toString());
        });
        Map<Integer, ItemStack> left = p.getInventory().addItem(item);
        left.values().forEach(i -> p.getWorld().dropItem(p.getLocation(), i));
        data.set(p.getUniqueId() + ".token", false);
        save();
    }

    public boolean isRevivePoint(Location loc) {
        String world = plugin.getConfig().getString("revive-point.world", "");
        if (world.isEmpty() || loc.getWorld() == null || !loc.getWorld().getName().equals(world)) return false;
        return loc.getBlockX() == plugin.getConfig().getInt("revive-point.x")
                && loc.getBlockY() == plugin.getConfig().getInt("revive-point.y")
                && loc.getBlockZ() == plugin.getConfig().getInt("revive-point.z");
    }
}
