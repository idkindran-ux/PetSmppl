package com.zebrawings.pets;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Wolf;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class PetTasks {
    private static class Job {
        final Location target;
        final boolean tpFallback;
        final long timeoutMs;
        final long start = System.currentTimeMillis();
        final String doneMsg;
        int fails = 0;

        Job(Location target, boolean tpFallback, long timeoutMs, String doneMsg) {
            this.target = target;
            this.tpFallback = tpFallback;
            this.timeoutMs = timeoutMs;
            this.doneMsg = doneMsg;
        }
    }

    private final ZebraPets plugin;
    private final PetManager pets;
    private final Map<UUID, Job> jobs = new HashMap<>();
    private final Map<UUID, Long> flyUntil = new HashMap<>();
    private int counter = 0;

    public PetTasks(ZebraPets plugin, PetManager pets) {
        this.plugin = plugin;
        this.pets = pets;
    }

    public void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 5L);
    }

    private void tick() {
        counter++;
        runJobs();
        if (counter % 2 == 0) maintain();
        if (counter % 4 == 0) checkFlight();
        if (counter % 20 == 0) passives();
    }

    // ---------- jobs (walk / ore) ----------
    public void startJob(Player p, Location target, boolean tpFallback, long timeoutMs, String doneMsg) {
        pets.setMode(p.getUniqueId(), PetManager.Mode.FOLLOW);
        jobs.put(p.getUniqueId(), new Job(target, tpFallback, timeoutMs, doneMsg));
    }

    public void cancelJob(UUID id) { jobs.remove(id); }

    public void cleanup(Player p) {
        jobs.remove(p.getUniqueId());
        endFlight(p);
    }

    private void runJobs() {
        for (Map.Entry<UUID, Job> en : new ArrayList<>(jobs.entrySet())) {
            UUID owner = en.getKey();
            Job j = en.getValue();
            Player p = Bukkit.getPlayer(owner);
            Wolf w = pets.getWolf(owner);
            if (p == null || w == null) { jobs.remove(owner); continue; }
            Location wl = w.getLocation();
            if (wl.getWorld() != j.target.getWorld()) { jobs.remove(owner); continue; }
            double ddx = wl.getX() - j.target.getX(), ddy = wl.getY() - j.target.getY(), ddz = wl.getZ() - j.target.getZ();
            double d2 = j.tpFallback ? ddx * ddx + ddy * ddy + ddz * ddz : ddx * ddx + ddz * ddz;
            if (d2 <= 6.25) {
                jobs.remove(owner);
                pets.say(p, j.doneMsg);
                continue;
            }
            if (System.currentTimeMillis() - j.start > j.timeoutMs) {
                jobs.remove(owner);
                if (j.tpFallback) {
                    w.teleport(j.target);
                    pets.say(p, j.doneMsg);
                } else {
                    pets.say(p, "I couldn't reach that place.");
                }
                continue;
            }
            boolean ok = w.getPathfinder().moveTo(j.target, 1.3);
            if (ok) {
                j.fails = 0;
            } else if (++j.fails >= 4) {
                j.fails = 0;
                if (j.tpFallback) w.teleport(j.target);
                else stepToward(w, j.target);
            }
        }
    }

    /** Fallback when the pet can't path to a far target: hop 4 blocks toward it along the surface. */
    private void stepToward(Wolf w, Location target) {
        Location cur = w.getLocation();
        double dx = target.getX() - cur.getX(), dz = target.getZ() - cur.getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.5) return;
        double step = Math.min(4.0, len);
        double nx = cur.getX() + dx / len * step, nz = cur.getZ() + dz / len * step;
        World world = cur.getWorld();
        int bx = (int) Math.floor(nx), bz = (int) Math.floor(nz);
        if (!world.isChunkLoaded(bx >> 4, bz >> 4)) return;
        double ny = world.getEnvironment() == World.Environment.NORMAL ? world.getHighestBlockYAt(bx, bz) + 1 : cur.getY();
        w.teleport(new Location(world, nx, ny, nz, cur.getYaw(), cur.getPitch()));
    }

    // ---------- maintenance ----------
    private void maintain() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            PetType t = pets.getPet(id);
            if (t == null || pets.isDead(id)) continue;
            Wolf w = pets.getWolf(id);
            if (w == null) { pets.spawn(p); continue; }
            PetManager.Mode mode = pets.getMode(id);
            if (!jobs.containsKey(id) && mode != PetManager.Mode.STAY) {
                if (w.getWorld() != p.getWorld() || w.getLocation().distanceSquared(p.getLocation()) > 900) {
                    w.teleport(p.getLocation());
                }
            }
            if (mode == PetManager.Mode.GUARD && w.getTarget() == null) {
                Monster nearest = null;
                double best = Double.MAX_VALUE;
                for (Entity e : p.getNearbyEntities(12, 6, 12)) {
                    if (e instanceof Monster m) {
                        double d = m.getLocation().distanceSquared(p.getLocation());
                        if (d < best) { best = d; nearest = m; }
                    }
                }
                if (nearest != null) w.setTarget(nearest);
            }
        }
    }

    private void passives() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            if (pets.getPet(id) == null || pets.isDead(id)) continue;
            Ability a = pets.getAbility(id);
            if (a != null && a.effect != null) {
                p.addPotionEffect(new PotionEffect(a.effect, 400, 0, true, false, true));
            }
            Wolf w = pets.getWolf(id);
            if (w != null) {
                AttributeInstance max = w.getAttribute(Attribute.MAX_HEALTH);
                if (max != null && w.getHealth() < max.getValue()) {
                    w.setHealth(Math.min(max.getValue(), w.getHealth() + 1.0));
                }
            }
        }
    }

    // ---------- flight ability ----------
    public void activateFlight(Player p) {
        UUID id = p.getUniqueId();
        if (pets.getAbility(id) != Ability.FLY || pets.isDead(id)) {
            p.sendMessage(Component.text("Your pet can't do that.", NamedTextColor.RED));
            return;
        }
        long now = System.currentTimeMillis();
        long ready = pets.getFlyReady(id);
        if (now < ready) {
            long mins = (ready - now) / 60000L;
            p.sendMessage(Component.text("Flight cooldown: " + (mins / 60) + "h " + (mins % 60) + "m left.", NamedTextColor.RED));
            return;
        }
        p.setAllowFlight(true);
        flyUntil.put(id, now + 5 * 60000L);
        pets.setFlyReady(id, now + 12 * 3600000L);
        pets.say(p, "Flight is on for 5 minutes!");
    }

    private void endFlight(Player p) {
        if (flyUntil.remove(p.getUniqueId()) != null
                && (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE)) {
            p.setFlying(false);
            p.setAllowFlight(false);
        }
    }

    private void checkFlight() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Long> en : new ArrayList<>(flyUntil.entrySet())) {
            Player p = Bukkit.getPlayer(en.getKey());
            if (p == null) { flyUntil.remove(en.getKey()); continue; }
            if (now > en.getValue()) {
                endFlight(p);
                pets.say(p, "Flight ended.");
            }
        }
    }

    // ---------- ore finder (75x75, loaded chunks only) ----------
    public void findOre(Player p, OreType ore) {
        UUID id = p.getUniqueId();
        Wolf w = pets.getWolf(id);
        if (w == null) {
            p.sendMessage(Component.text("Your pet isn't here.", NamedTextColor.RED));
            return;
        }
        final Location c = w.getLocation();
        final World world = c.getWorld();
        final int half = 37;
        final int minX = c.getBlockX() - half, maxX = c.getBlockX() + half;
        final int minZ = c.getBlockZ() - half, maxZ = c.getBlockZ() + half;
        final List<int[]> chunks = new ArrayList<>();
        for (int cx = minX >> 4; cx <= (maxX >> 4); cx++) {
            for (int cz = minZ >> 4; cz <= (maxZ >> 4); cz++) chunks.add(new int[]{cx, cz});
        }
        final Set<Material> types = ore.types();
        pets.say(p, "Searching for " + ore.label + " nearby...");
        new BukkitRunnable() {
            int idx = 0;
            Location best = null;
            double bestD = Double.MAX_VALUE;

            @Override
            public void run() {
                if (!p.isOnline()) { cancel(); return; }
                int n = 0;
                while (idx < chunks.size() && n < 2) {
                    int[] ch = chunks.get(idx++);
                    n++;
                    if (!world.isChunkLoaded(ch[0], ch[1])) continue;
                    ChunkSnapshot snap = world.getChunkAt(ch[0], ch[1]).getChunkSnapshot();
                    for (int x = 0; x < 16; x++) {
                        int wx = ch[0] * 16 + x;
                        if (wx < minX || wx > maxX) continue;
                        for (int z = 0; z < 16; z++) {
                            int wz = ch[1] * 16 + z;
                            if (wz < minZ || wz > maxZ) continue;
                            int top = Math.min(world.getMaxHeight() - 1, snap.getHighestBlockYAt(x, z));
                            for (int y = world.getMinHeight(); y <= top; y++) {
                                if (types.contains(snap.getBlockType(x, y, z))) {
                                    double dx = wx - c.getX(), dy = y - c.getY(), dz = wz - c.getZ();
                                    double d = dx * dx + dy * dy + dz * dz;
                                    if (d < bestD) {
                                        bestD = d;
                                        best = new Location(world, wx, y, wz);
                                    }
                                }
                            }
                        }
                    }
                }
                if (idx >= chunks.size()) {
                    cancel();
                    finishOre(p, ore, best);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void finishOre(Player p, OreType ore, Location best) {
        if (best == null) {
            pets.say(p, "I couldn't find any " + ore.label + " within 75x75 blocks.");
            return;
        }
        String coords = best.getBlockX() + " " + best.getBlockY() + " " + best.getBlockZ();
        Location stand = findStandSpot(best);
        if (stand == null) {
            pets.say(p, "I found " + ore.label + " at " + coords + ", but it's buried.");
            return;
        }
        pets.say(p, "Found " + ore.label + " at " + coords + "! Following me...");
        startJob(p, stand, true, 45000L, "I'm standing on the ore! (" + coords + ")");
    }

    private Location findStandSpot(Location ore) {
        Block b = ore.getBlock();
        BlockFace[] faces = {BlockFace.UP, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};
        for (BlockFace f : faces) {
            Block n = b.getRelative(f);
            if (n.isPassable() && !n.isLiquid() && n.getRelative(BlockFace.UP).isPassable()) {
                return n.getLocation().add(0.5, f == BlockFace.UP ? 0.0 : 0.0, 0.5);
            }
        }
        return null;
    }
}
