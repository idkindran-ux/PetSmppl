package com.zebrawings.pets;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PetChat implements Listener {
    private static final Pattern NUM = Pattern.compile("-?\\d+");
    private final ZebraPets plugin;
    private final PetManager pets;
    private final PetTasks tasks;
    private final AiClient ai;
    private final Map<UUID, Long> talkUntil = new ConcurrentHashMap<>();
    private final Set<UUID> coordPrompt = ConcurrentHashMap.newKeySet();

    public PetChat(ZebraPets plugin, PetManager pets, PetTasks tasks, AiClient ai) {
        this.plugin = plugin;
        this.pets = pets;
        this.tasks = tasks;
        this.ai = ai;
    }

    public void startTalk(Player p) {
        talkUntil.put(p.getUniqueId(), System.currentTimeMillis() + 120000L);
        pets.say(p, "I'm listening! Type in chat. Say 'bye' to stop.");
        p.sendMessage(Component.text("Tip: you can say 'find diamond', '100 70 -250', 'stay', 'guard' or 'follow'.", NamedTextColor.GRAY));
    }

    public void startCoordPrompt(Player p) {
        coordPrompt.add(p.getUniqueId());
        p.sendMessage(Component.text("Type the coordinates in chat, like: 100 70 -250 (or just 100 -250). Type 'cancel' to stop.", NamedTextColor.YELLOW));
    }

    public void forget(UUID id) {
        talkUntil.remove(id);
        coordPrompt.remove(id);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        boolean prompt = coordPrompt.contains(id);
        Long until = talkUntil.get(id);
        boolean talking = until != null && until > System.currentTimeMillis();
        if (!prompt && !talking) return;
        e.setCancelled(true);
        String msg = PlainTextComponentSerializer.plainText().serialize(e.message());
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (prompt) handleCoords(p, msg);
            else handleTalk(p, msg);
        });
    }

    private void handleCoords(Player p, String msg) {
        coordPrompt.remove(p.getUniqueId());
        if (msg.trim().equalsIgnoreCase("cancel")) {
            p.sendMessage(Component.text("Cancelled.", NamedTextColor.GRAY));
            return;
        }
        List<Integer> nums = ints(msg);
        if (nums.size() < 2 || nums.size() > 3) {
            p.sendMessage(Component.text("I couldn't read those coordinates. Open the menu and try again.", NamedTextColor.RED));
            return;
        }
        walk(p, nums);
    }

    private void handleTalk(Player p, String msg) {
        UUID id = p.getUniqueId();
        talkUntil.put(id, System.currentTimeMillis() + 120000L);
        p.sendMessage(Component.text("You: " + msg, NamedTextColor.GRAY));
        String l = msg.toLowerCase(Locale.ROOT).trim();
        if (l.equals("bye") || l.equals("exit") || l.equals("stop talking")) {
            talkUntil.remove(id);
            pets.say(p, "Bye! Right-click me anytime.");
            return;
        }
        List<Integer> nums = ints(l);
        boolean onlyNumbers = l.matches("^[\\d\\s,.\\-]+$");
        if (nums.size() >= 2 && nums.size() <= 3 && (onlyNumbers || containsAny(l, "go", "walk", "move", "cord", "take", "reach"))) {
            walk(p, nums);
            return;
        }
        if (hasWord(l, "find", "search", "locate") || l.contains("look for")) {
            for (OreType o : OreType.values()) {
                if (o != OreType.ANY && l.contains(o.keyword)) {
                    tasks.findOre(p, o);
                    return;
                }
            }
            if (hasWord(l, "ore", "ores", "any")) {
                tasks.findOre(p, OreType.ANY);
                return;
            }
        }
        if (hasWord(l, "stay", "sit", "wait")) {
            tasks.cancelJob(id);
            pets.setMode(id, PetManager.Mode.STAY);
            pets.say(p, "Okay, I'll stay here.");
            return;
        }
        if (hasWord(l, "guard", "protect", "fight", "attack")) {
            tasks.cancelJob(id);
            pets.setMode(id, PetManager.Mode.GUARD);
            pets.say(p, "Guard mode on! I'll fight for you.");
            return;
        }
        if (hasWord(l, "follow", "come")) {
            tasks.cancelJob(id);
            pets.setMode(id, PetManager.Mode.FOLLOW);
            pets.say(p, "Coming!");
            return;
        }
        PetType t = pets.getPet(id);
        if (t == null) return;
        ai.ask(t.name(), t.rarity().label, p.getName(), msg, reply -> {
            if (p.isOnline()) pets.say(p, reply);
        });
    }

    private void walk(Player p, List<Integer> nums) {
        World w = p.getWorld();
        int x = nums.get(0);
        int y, z;
        if (nums.size() == 2) {
            z = nums.get(1);
            y = w.getHighestBlockYAt(x, z) + 1;
        } else {
            y = nums.get(1);
            z = nums.get(2);
        }
        Location target = new Location(w, x + 0.5, y, z + 0.5);
        tasks.startJob(p, target, false, 120000L, "We're here!");
        pets.say(p, "Okay! Follow me to " + x + " " + y + " " + z + "!");
    }

    private static List<Integer> ints(String s) {
        List<Integer> out = new ArrayList<>();
        Matcher m = NUM.matcher(s);
        while (m.find()) {
            try { out.add(Integer.parseInt(m.group())); } catch (NumberFormatException ignored) { }
        }
        return out;
    }

    private static boolean hasWord(String s, String... words) {
        for (String w : words) {
            if (Pattern.compile("\\b" + Pattern.quote(w) + "\\b").matcher(s).find()) return true;
        }
        return false;
    }

    private static boolean containsAny(String s, String... words) {
        for (String w : words) if (s.contains(w)) return true;
        return false;
    }
}
