package com.zebrawings.pets;

/** Small-caps style text (works without a resource pack). Toggle with fancy-fonts in config.yml. */
public final class Fancy {
    private static boolean enabled = true;
    private static final String SC = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ";

    private Fancy() {}

    public static void setEnabled(boolean b) { enabled = b; }

    public static String sc(String s) {
        if (!enabled) return s;
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            char l = Character.toLowerCase(c);
            if (l >= 'a' && l <= 'z') b.append(SC.charAt(l - 'a'));
            else b.append(c);
        }
        return b.toString();
    }
}
