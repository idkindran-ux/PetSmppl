package com.zebrawings.pets;

import org.bukkit.Material;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Set;

public enum OreType {
    COAL("Coal", "coal", Material.COAL, Material.COAL_ORE, Material.DEEPSLATE_COAL_ORE),
    IRON("Iron", "iron", Material.RAW_IRON, Material.IRON_ORE, Material.DEEPSLATE_IRON_ORE),
    COPPER("Copper", "copper", Material.RAW_COPPER, Material.COPPER_ORE, Material.DEEPSLATE_COPPER_ORE),
    GOLD("Gold", "gold", Material.RAW_GOLD, Material.GOLD_ORE, Material.DEEPSLATE_GOLD_ORE, Material.NETHER_GOLD_ORE),
    REDSTONE("Redstone", "redstone", Material.REDSTONE, Material.REDSTONE_ORE, Material.DEEPSLATE_REDSTONE_ORE),
    LAPIS("Lapis", "lapis", Material.LAPIS_LAZULI, Material.LAPIS_ORE, Material.DEEPSLATE_LAPIS_ORE),
    DIAMOND("Diamond", "diamond", Material.DIAMOND, Material.DIAMOND_ORE, Material.DEEPSLATE_DIAMOND_ORE),
    EMERALD("Emerald", "emerald", Material.EMERALD, Material.EMERALD_ORE, Material.DEEPSLATE_EMERALD_ORE),
    QUARTZ("Quartz", "quartz", Material.QUARTZ, Material.NETHER_QUARTZ_ORE),
    ANY("Any Ore", "any", Material.NETHERITE_PICKAXE);

    public final String label;
    public final String keyword;
    public final Material icon;
    private final Set<Material> blocks = EnumSet.noneOf(Material.class);

    OreType(String label, String keyword, Material icon, Material... blocks) {
        this.label = label;
        this.keyword = keyword;
        this.icon = icon;
        this.blocks.addAll(Arrays.asList(blocks));
    }

    /** Ancient debris is intentionally never included. */
    public Set<Material> types() {
        if (this != ANY) return blocks;
        Set<Material> all = EnumSet.noneOf(Material.class);
        for (OreType o : values()) if (o != ANY) all.addAll(o.blocks);
        return all;
    }
}
