package com.zebrawings.pets;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.entity.Wolf;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PetMenu implements Listener {
    private enum Type { MAIN, ORE }

    private static class Holder implements InventoryHolder {
        final Type type;
        Inventory inv;

        Holder(Type type) { this.type = type; }

        @Override
        public Inventory getInventory() { return inv; }
    }

    private static final int[] ORE_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21};

    private final ZebraPets plugin;
    private final PetManager pets;
    private final PetTasks tasks;
    private final PetChat chat;

    public PetMenu(ZebraPets plugin, PetManager pets, PetTasks tasks, PetChat chat) {
        this.plugin = plugin;
        this.pets = pets;
        this.tasks = tasks;
        this.chat = chat;
    }

    private static ItemStack item(Material m, Component name, Component... lore) {
        ItemStack it = new ItemStack(m);
        it.editMeta(meta -> {
            meta.displayName(name.decoration(TextDecoration.ITALIC, false));
            if (lore.length > 0) {
                List<Component> l = new ArrayList<>();
                for (Component c : lore) l.add(c.decoration(TextDecoration.ITALIC, false));
                meta.lore(l);
            }
        });
        return it;
    }

    private static Component txt(String s, NamedTextColor c) { return Component.text(s, c); }

    private static void fill(Inventory inv) {
        ItemStack filler = item(Material.GRAY_STAINED_GLASS_PANE, Component.text(" "));
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);
    }

    public void openMain(Player p) {
        UUID id = p.getUniqueId();
        PetType t = pets.getPet(id);
        if (t == null) return;
        Holder h = new Holder(Type.MAIN);
        Inventory inv = Bukkit.createInventory(h, 27, Component.text(Fancy.sc("Pet Menu"), NamedTextColor.DARK_GRAY));
        h.inv = inv;
        fill(inv);
        Rarity r = t.rarity();
        Ability a = pets.getAbility(id);

        inv.setItem(4, item(Material.NAME_TAG, Component.text(Fancy.sc(t.name()), r.color),
                txt("Rarity: " + r.label + " (" + r.percentText() + ")", r.color),
                txt("Health: " + r.hearts + " hearts", NamedTextColor.GRAY),
                txt(pets.isDead(id) ? "Status: Dead" : "Status: Alive", NamedTextColor.GRAY)));

        if (a == null) {
            inv.setItem(10, item(Material.BARRIER, txt(Fancy.sc("No ability"), NamedTextColor.RED)));
        } else if (a == Ability.FLY) {
            inv.setItem(10, item(a.icon, txt(Fancy.sc("Ability: " + a.label), NamedTextColor.GOLD),
                    txt("Click to fly for 5 minutes", NamedTextColor.GRAY),
                    txt("(once every 12 hours)", NamedTextColor.GRAY)));
        } else {
            inv.setItem(10, item(a.icon, txt(Fancy.sc("Ability: " + a.label), NamedTextColor.GOLD),
                    txt("Always active while your pet is alive", NamedTextColor.GRAY)));
        }

        inv.setItem(12, item(Material.DIAMOND_PICKAXE, txt(Fancy.sc("Find Ore"), NamedTextColor.AQUA),
                txt("Pet searches 75x75 blocks", NamedTextColor.GRAY),
                txt("and stands on the ore", NamedTextColor.GRAY)));
        inv.setItem(14, item(Material.COMPASS, txt(Fancy.sc("Walk to Coordinates"), NamedTextColor.GREEN),
                txt("Pet walks there, you follow", NamedTextColor.GRAY)));
        PetManager.Mode mode = pets.getMode(id);
        inv.setItem(16, item(Material.LEAD, txt(Fancy.sc("Mode: " + mode.name()), NamedTextColor.YELLOW),
                txt("Click: Follow > Stay > Guard", NamedTextColor.GRAY)));
        inv.setItem(22, item(Material.WRITABLE_BOOK, txt(Fancy.sc("Talk to Pet"), NamedTextColor.LIGHT_PURPLE),
                txt("Chat with your pet or give it orders", NamedTextColor.GRAY)));

        List<Component> chances = new ArrayList<>();
        for (Rarity x : Rarity.values()) chances.add(txt(x.label + ": " + x.percentText(), x.color));
        inv.setItem(26, item(Material.BOOK, txt(Fancy.sc("Rarity Chances"), NamedTextColor.WHITE), chances.toArray(new Component[0])));
        p.openInventory(inv);
    }

    private void openOre(Player p) {
        Holder h = new Holder(Type.ORE);
        Inventory inv = Bukkit.createInventory(h, 27, Component.text(Fancy.sc("Find Ore"), NamedTextColor.DARK_GRAY));
        h.inv = inv;
        fill(inv);
        OreType[] ores = OreType.values();
        for (int i = 0; i < ores.length && i < ORE_SLOTS.length; i++) {
            inv.setItem(ORE_SLOTS[i], item(ores[i].icon, txt(Fancy.sc(ores[i].label), NamedTextColor.GOLD),
                    txt("Click to search", NamedTextColor.GRAY)));
        }
        inv.setItem(22, item(Material.ARROW, txt(Fancy.sc("Back"), NamedTextColor.RED)));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        int slot = e.getRawSlot();
        UUID id = p.getUniqueId();
        if (h.type == Type.MAIN) {
            switch (slot) {
                case 10 -> {
                    p.closeInventory();
                    if (pets.getAbility(id) == Ability.FLY) tasks.activateFlight(p);
                }
                case 12 -> Bukkit.getScheduler().runTask(plugin, () -> openOre(p));
                case 14 -> {
                    p.closeInventory();
                    chat.startCoordPrompt(p);
                }
                case 16 -> {
                    PetManager.Mode[] ms = PetManager.Mode.values();
                    PetManager.Mode next = ms[(pets.getMode(id).ordinal() + 1) % ms.length];
                    tasks.cancelJob(id);
                    pets.setMode(id, next);
                    Bukkit.getScheduler().runTask(plugin, () -> openMain(p));
                }
                case 22 -> {
                    p.closeInventory();
                    chat.startTalk(p);
                }
                default -> { }
            }
        } else {
            if (slot == 22) {
                Bukkit.getScheduler().runTask(plugin, () -> openMain(p));
                return;
            }
            OreType[] ores = OreType.values();
            for (int i = 0; i < ores.length && i < ORE_SLOTS.length; i++) {
                if (ORE_SLOTS[i] == slot) {
                    p.closeInventory();
                    tasks.findOre(p, ores[i]);
                    return;
                }
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder(false) instanceof Holder) e.setCancelled(true);
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e) {
        if (!(e.getRightClicked() instanceof Wolf w)) return;
        String owner = w.getPersistentDataContainer().get(pets.keyOwner, PersistentDataType.STRING);
        if (owner == null) return;
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        if (!p.getUniqueId().toString().equals(owner)) {
            p.sendMessage(Component.text("This isn't your pet.", NamedTextColor.RED));
            return;
        }
        openMain(p);
    }
}
