package com.zebrawings.pets;

import org.bukkit.Bukkit;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Random;
import java.util.function.Consumer;

public class AiClient {
    private static final String[] FALLBACK = {
            "I'm right here with you!", "Let's go on an adventure!", "I'll protect you!",
            "Tell me where to go, I'll follow.", "I love being your pet!"
    };
    private final ZebraPets plugin;
    private final Random rng = new Random();
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();

    public AiClient(ZebraPets plugin) { this.plugin = plugin; }

    private String fallback() { return FALLBACK[rng.nextInt(FALLBACK.length)]; }

    public void ask(String petName, String rarity, String owner, String msg, Consumer<String> callback) {
        String key = plugin.getConfig().getString("ai.api-key", "").trim();
        if (key.isEmpty()) { callback.accept(fallback()); return; }
        String model = plugin.getConfig().getString("ai.model", "gemini-2.5-flash");
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            String reply = null;
            try {
                String sys = "You are " + petName + ", a " + rarity + " pet animal in Minecraft, loyal to your owner "
                        + owner + ". Reply in one or two short, cute sentences. Reply in the same language the owner writes in.";
                String body = "{\"system_instruction\":{\"parts\":[{\"text\":\"" + esc(sys) + "\"}]},"
                        + "\"contents\":[{\"role\":\"user\",\"parts\":[{\"text\":\"" + esc(msg) + "\"}]}],"
                        + "\"generationConfig\":{\"maxOutputTokens\":300,\"thinkingConfig\":{\"thinkingBudget\":0}}}";
                HttpRequest req = HttpRequest.newBuilder(URI.create(
                                "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + key))
                        .timeout(Duration.ofSeconds(20))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(body)).build();
                HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() == 200) reply = extractText(res.body());
                else plugin.getLogger().warning("Pet AI returned HTTP " + res.statusCode());
            } catch (Exception ex) {
                plugin.getLogger().warning("Pet AI failed: " + ex.getClass().getSimpleName());
            }
            String out = (reply == null || reply.isBlank()) ? fallback() : reply.trim();
            if (out.length() > 220) out = out.substring(0, 220) + "...";
            final String finalOut = out;
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(finalOut));
        });
    }

    private static String esc(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n");
                case '\r' -> { }
                case '\t' -> b.append("\\t");
                default -> {
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
                }
            }
        }
        return b.toString();
    }

    private static String extractText(String json) {
        int i = json.indexOf("\"text\"");
        if (i < 0) return null;
        i = json.indexOf(':', i);
        if (i < 0) return null;
        i = json.indexOf('"', i);
        if (i < 0) return null;
        i++;
        StringBuilder b = new StringBuilder();
        for (; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '"') break;
            if (c == '\\' && i + 1 < json.length()) {
                char n = json.charAt(++i);
                switch (n) {
                    case 'n' -> b.append('\n');
                    case 't' -> b.append('\t');
                    case 'u' -> {
                        if (i + 4 < json.length()) {
                            b.append((char) Integer.parseInt(json.substring(i + 1, i + 5), 16));
                            i += 4;
                        }
                    }
                    default -> b.append(n);
                }
            } else {
                b.append(c);
            }
        }
        return b.toString();
    }
}
