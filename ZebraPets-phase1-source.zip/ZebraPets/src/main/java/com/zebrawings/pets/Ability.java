package com.zebrawings.pets;

import org.bukkit.Material;
import org.bukkit.potion.PotionEffectType;

public enum Ability {
    NIGHT_VISION("Night Vision", PotionEffectType.NIGHT_VISION, Material.GOLDEN_CARROT),
    SPEED("Speed", PotionEffectType.SPEED, Material.SUGAR),
    JUMP("Jump Boost", PotionEffectType.JUMP_BOOST, Material.RABBIT_FOOT),
    REGEN("Regeneration", PotionEffectType.REGENERATION, Material.GHAST_TEAR),
    FIRE_RES("Fire Resistance", PotionEffectType.FIRE_RESISTANCE, Material.MAGMA_CREAM),
    WATER_BREATH("Water Breathing", PotionEffectType.WATER_BREATHING, Material.PUFFERFISH),
    HASTE("Haste", PotionEffectType.HASTE, Material.GOLDEN_PICKAXE),
    STRENGTH("Strength", PotionEffectType.STRENGTH, Material.BLAZE_POWDER),
    RESISTANCE("Resistance", PotionEffectType.RESISTANCE, Material.IRON_CHESTPLATE),
    FLY("Flight (5 min every 12 h)", null, Material.FEATHER);

    public final String label;
    public final PotionEffectType effect;
    public final Material icon;

    Ability(String label, PotionEffectType effect, Material icon) {
        this.label = label;
        this.effect = effect;
        this.icon = icon;
    }
}
