package com.zebrawings.pets;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class ZebraPets extends JavaPlugin implements CommandExecutor {
    private PetManager manager;
    private PetMenu menu;
    private Economy economy;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getConfig().options().copyDefaults(true);
        saveConfig();
        Rarity.load(getConfig());
        Fancy.setEnabled(getConfig().getBoolean("fancy-fonts", true));
        PetRegistry.load(this);

        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            getLogger().severe("No Vault economy found (install an economy plugin + Vault). Disabling.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        economy = rsp.getProvider();
        manager = new PetManager(this);
        PetTasks tasks = new PetTasks(this, manager);
        PetChat chat = new PetChat(this, manager, tasks, new AiClient(this));
        menu = new PetMenu(this, manager, tasks, chat);
        getServer().getPluginManager().registerEvents(new PetListener(this, manager, tasks, chat), this);
        getServer().getPluginManager().registerEvents(chat, this);
        getServer().getPluginManager().registerEvents(menu, this);
        getCommand("zpets").setExecutor(this);
        getCommand("pet").setExecutor(this);
        manager.startLabelTask();
        tasks.start();
        for (Player p : Bukkit.getOnlinePlayers()) manager.ensureAndSpawn(p);
    }

    @Override
    public void onDisable() {
        if (manager != null) { manager.despawnAll(); manager.save(); }
    }

    public Economy economy() { return economy; }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (c.getName().equalsIgnoreCase("pet")) {
            if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
            menu.openMain(p);
            return true;
        }
        if (!s.hasPermission("zebrapets.admin")) { s.sendMessage("No permission."); return true; }
        if (a.length == 0) { s.sendMessage("/zpets <give|take|info|setrevive|reload> [player]"); return true; }
        switch (a[0].toLowerCase()) {
            case "reload" -> {
                reloadConfig();
                Rarity.load(getConfig());
        Fancy.setEnabled(getConfig().getBoolean("fancy-fonts", true));
                PetRegistry.load(this);
                s.sendMessage("ZebraPets reloaded.");
            }
            case "setrevive" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
                Block b = p.getTargetBlockExact(6);
                if (b == null) { p.sendMessage("Look at the ground where the altar should go."); return true; }
                Location altar = buildAltar(b);
                getConfig().set("revive-point.world", altar.getWorld().getName());
                getConfig().set("revive-point.x", altar.getBlockX());
                getConfig().set("revive-point.y", altar.getBlockY());
                getConfig().set("revive-point.z", altar.getBlockZ());
                saveConfig();
                p.sendMessage(Component.text("Revival altar built! Right-click the crying obsidian with a Revive Token.", NamedTextColor.GREEN));
            }
            case "give", "take", "info" -> {
                if (a.length < 2) { s.sendMessage("Specify a player."); return true; }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) { s.sendMessage("Player must be online."); return true; }
                PetType cur = manager.getPet(t.getUniqueId());
                switch (a[0].toLowerCase()) {
                    case "info" -> s.sendMessage(t.getName() + ": " + (cur == null ? "none" : cur.name() + " (" + cur.rarity().label + ")"));
                    case "give" -> { manager.setPet(t.getUniqueId(), PetRegistry.zebra()); manager.spawn(t); s.sendMessage("Gave Zebra to " + t.getName()); }
                    case "take" -> {
                        if (cur == null || cur.rarity() != Rarity.ADMIN) { s.sendMessage("They don't have the Zebra."); return true; }
                        manager.setPet(t.getUniqueId(), PetRegistry.random());
                        manager.spawn(t);
                        s.sendMessage("Took Zebra from " + t.getName() + " and gave a random pet.");
                    }
                    default -> { }
                }
            }
            default -> s.sendMessage("/zpets <give|take|info|setrevive|reload> [player]");
        }
        return true;
    }

    /** 5x5 altar: stone-brick floor, blackstone center, 4 pillars with soul lanterns, crying obsidian altar block. */
    private Location buildAltar(Block target) {
        World w = target.getWorld();
        int cx = target.getX(), cy = target.getY(), cz = target.getZ();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                boolean inner = Math.abs(dx) <= 1 && Math.abs(dz) <= 1;
                w.getBlockAt(cx + dx, cy, cz + dz).setType(inner ? Material.POLISHED_BLACKSTONE_BRICKS : Material.STONE_BRICKS, false);
                for (int dy = 1; dy <= 4; dy++) w.getBlockAt(cx + dx, cy + dy, cz + dz).setType(Material.AIR, false);
            }
        }
        for (int sx : new int[]{-2, 2}) {
            for (int sz : new int[]{-2, 2}) {
                for (int dy = 1; dy <= 3; dy++) w.getBlockAt(cx + sx, cy + dy, cz + sz).setType(Material.CHISELED_STONE_BRICKS, false);
                w.getBlockAt(cx + sx, cy + 4, cz + sz).setType(Material.SOUL_LANTERN, false);
            }
        }
        Block altar = w.getBlockAt(cx, cy + 1, cz);
        altar.setType(Material.CRYING_OBSIDIAN, false);
        return altar.getLocation();
    }
}
