package com.zebrawings.pets;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class ZebraPets extends JavaPlugin implements CommandExecutor {
    private PetManager manager;
    private Economy economy;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            getLogger().severe("No Vault economy found (install EssentialsX + Vault). Disabling.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        economy = rsp.getProvider();
        manager = new PetManager(this);
        getServer().getPluginManager().registerEvents(new PetListener(this, manager), this);
        getCommand("zpets").setExecutor(this);
        for (Player p : Bukkit.getOnlinePlayers()) manager.ensureAndSpawn(p);
    }

    @Override
    public void onDisable() {
        if (manager != null) { manager.despawnAll(); manager.save(); }
    }

    public Economy economy() { return economy; }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("zebrapets.admin")) { s.sendMessage("No permission."); return true; }
        if (a.length == 0) { s.sendMessage("/zpets <give|take|setrevive|info> [player]"); return true; }
        switch (a[0].toLowerCase()) {
            case "setrevive" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
                Block b = p.getTargetBlockExact(6);
                if (b == null) { p.sendMessage("Look at a block."); return true; }
                getConfig().set("revive-point.world", b.getWorld().getName());
                getConfig().set("revive-point.x", b.getX());
                getConfig().set("revive-point.y", b.getY());
                getConfig().set("revive-point.z", b.getZ());
                saveConfig();
                p.sendMessage(Component.text("Revival point set.", NamedTextColor.GREEN));
            }
            case "give", "take", "info" -> {
                if (a.length < 2) { s.sendMessage("Specify a player."); return true; }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) { s.sendMessage("Player must be online."); return true; }
                PetType cur = manager.getPet(t.getUniqueId());
                switch (a[0].toLowerCase()) {
                    case "info" -> s.sendMessage(t.getName() + ": " + (cur == null ? "none" : cur.name() + " (" + cur.rarity().label + ")"));
                    case "give" -> { manager.setPet(t.getUniqueId(), PetRegistry.zebra()); manager.spawn(t); s.sendMessage("Gave Zebra to " + t.getName()); }
                    case "take" -> {
                        if (cur == null || cur.rarity() != Rarity.ADMIN) { s.sendMessage("They don't have the Zebra."); return true; }
                        manager.setPet(t.getUniqueId(), PetRegistry.random());
                        manager.spawn(t);
                        s.sendMessage("Took Zebra from " + t.getName() + " and gave a random pet.");
                    }
                }
            }
            default -> s.sendMessage("/zpets <give|take|setrevive|info> [player]");
        }
        return true;
    }
}
