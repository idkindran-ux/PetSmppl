package com.zebrawings.pets;

import net.kyori.adventure.text.format.NamedTextColor;

public enum Rarity {
    COMMON("Common", 60, 20, NamedTextColor.GRAY),
    UNCOMMON("Uncommon", 25, 25, NamedTextColor.GREEN),
    RARE("Rare", 10, 32, NamedTextColor.BLUE),
    VERY_RARE("Very Rare", 4, 40, NamedTextColor.DARK_PURPLE),
    ULTRA_RARE("Ultra Rare", 1, 50, NamedTextColor.GOLD),
    ADMIN("Admin", 0, 50, NamedTextColor.RED);

    public final String label;
    public final int weight;
    public final int hearts;
    public final NamedTextColor color;

    Rarity(String label, int weight, int hearts, NamedTextColor color) {
        this.label = label;
        this.weight = weight;
        this.hearts = hearts;
        this.color = color;
    }
}
