package com.zebrawings.pets;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.configuration.file.FileConfiguration;

public enum Rarity {
    COMMON("Common", "common", NamedTextColor.GREEN, "<green>", 60, 20),
    UNCOMMON("Uncommon", "uncommon", NamedTextColor.DARK_GREEN, "<dark_green>", 25, 25),
    RARE("Rare", "rare", NamedTextColor.YELLOW, "<yellow>", 10, 32),
    VERY_RARE("Very Rare", "very_rare", NamedTextColor.RED, "<red>", 4, 40),
    ULTRA_RARE("Ultra Rare", "ultra_rare", NamedTextColor.GOLD, "<gradient:red:yellow>", 1, 50),
    ADMIN("Admin", "admin", NamedTextColor.AQUA, "<aqua>", 0, 50);

    public final String label;
    public final String key;
    public final NamedTextColor color;
    public final String mini;
    public double chance;
    public int hearts;

    Rarity(String label, String key, NamedTextColor color, String mini, double chance, int hearts) {
        this.label = label;
        this.key = key;
        this.color = color;
        this.mini = mini;
        this.chance = chance;
        this.hearts = hearts;
    }

    public static void load(FileConfiguration cfg) {
        for (Rarity r : values()) {
            r.chance = cfg.getDouble("rarities." + r.key + ".chance", r.chance);
            r.hearts = Math.max(1, Math.min(100, cfg.getInt("rarities." + r.key + ".hearts", r.hearts)));
        }
    }

    public static double total() {
        double t = 0;
        for (Rarity r : values()) if (r != ADMIN) t += r.chance;
        return t;
    }

    public double percent() {
        double t = total();
        return (this == ADMIN || t <= 0) ? 0 : chance / t * 100.0;
    }

    public String percentText() {
        return this == ADMIN ? "Admin only" : String.format("%.1f%%", percent());
    }
}
