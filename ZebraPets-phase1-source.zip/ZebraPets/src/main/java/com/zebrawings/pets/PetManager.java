package com.zebrawings.pets;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Wolf;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class PetManager {
    public enum Mode { FOLLOW, STAY, GUARD }

    private final ZebraPets plugin;
    private final File file;
    private final YamlConfiguration data;
    private final Map<UUID, UUID> active = new HashMap<>();
    private final Map<UUID, List<UUID>> labels = new HashMap<>();
    private final Map<UUID, Mode> modes = new HashMap<>();
    private final Random rng = new Random();
    public final NamespacedKey keyOwner;
    public final NamespacedKey keyToken;

    public PetManager(ZebraPets plugin) {
        this.plugin = plugin;
        this.keyOwner = new NamespacedKey(plugin, "pet_owner");
        this.keyToken = new NamespacedKey(plugin, "revive_token");
        this.file = new File(plugin.getDataFolder(), "data.yml");
        plugin.getDataFolder().mkdirs();
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    public void save() {
        try { data.save(file); } catch (IOException e) { plugin.getLogger().warning("Save failed: " + e.getMessage()); }
    }

    // ---------- data ----------
    public PetType getPet(UUID owner) {
        String id = data.getString(owner + ".pet");
        return id == null ? null : PetRegistry.byId(id);
    }

    public boolean isDead(UUID owner) { return data.getBoolean(owner + ".dead"); }

    public void setPet(UUID owner, PetType type) {
        data.set(owner + ".pet", type.id());
        data.set(owner + ".dead", false);
        save();
    }

    public Ability getAbility(UUID owner) {
        String n = data.getString(owner + ".ability");
        if (n == null) return null;
        try { return Ability.valueOf(n); } catch (IllegalArgumentException e) { return null; }
    }

    public long getFlyReady(UUID owner) { return data.getLong(owner + ".flyready", 0L); }

    public void setFlyReady(UUID owner, long t) { data.set(owner + ".flyready", t); save(); }

    public void markDead(UUID owner) {
        data.set(owner + ".dead", true);
        data.set(owner + ".token", true);
        active.remove(owner);
        save();
    }

    public void revive(Player p) {
        data.set(p.getUniqueId() + ".dead", false);
        save();
        spawn(p);
    }

    public Mode getMode(UUID owner) { return modes.getOrDefault(owner, Mode.FOLLOW); }

    public void setMode(UUID owner, Mode m) {
        modes.put(owner, m);
        Wolf w = getWolf(owner);
        if (w != null) w.setSitting(m == Mode.STAY);
    }

    public Wolf getWolf(UUID owner) {
        UUID id = active.get(owner);
        if (id == null) return null;
        Entity e = Bukkit.getEntity(id);
        return (e instanceof Wolf w && w.isValid()) ? w : null;
    }

    public Set<UUID> activeOwners() { return new HashSet<>(active.keySet()); }

    // ---------- messages ----------
    public void say(Player p, String text) {
        PetType t = getPet(p.getUniqueId());
        Component name = Component.text("[" + (t == null ? "Pet" : Fancy.sc(t.name())) + "] ",
                t == null ? NamedTextColor.WHITE : t.rarity().color);
        p.sendMessage(name.append(Component.text(text, NamedTextColor.WHITE)));
    }

    // ---------- join / spawn ----------
    public void ensureAndSpawn(Player p) {
        UUID id = p.getUniqueId();
        PetType cur = getPet(id);
        if (cur == null) {
            PetType t = PetRegistry.random();
            setPet(id, t);
            p.sendMessage(Component.text("You got a ", NamedTextColor.YELLOW)
                    .append(Component.text(t.name(), t.rarity().color, TextDecoration.BOLD))
                    .append(Component.text(" (" + t.rarity().label + ", " + t.rarity().percentText() + " chance)! You can't change it.", NamedTextColor.YELLOW)));
        }
        if (getAbility(id) == null) {
            Ability a = Ability.values()[rng.nextInt(Ability.values().length)];
            data.set(id + ".ability", a.name());
            save();
            p.sendMessage(Component.text("Your pet's ability: ", NamedTextColor.YELLOW)
                    .append(Component.text(a.label, NamedTextColor.GOLD)));
        }
        if (data.getBoolean(id + ".token")) giveToken(p);
        spawn(p);
    }

    public void spawn(Player p) {
        UUID id = p.getUniqueId();
        despawn(id);
        PetType t = getPet(id);
        if (t == null || isDead(id)) return;
        double hp = t.rarity().hearts * 2.0;
        double atk = 4.0 + (t.rarity().hearts - 20) / 6.0;
        Wolf pet = p.getWorld().spawn(p.getLocation(), Wolf.class, w -> {
            w.setOwner(p);
            w.setPersistent(false);
            w.setCustomNameVisible(false);
            w.customName(Component.text(t.name() + " | " + p.getName(), t.rarity().color));
            AttributeInstance max = w.getAttribute(Attribute.MAX_HEALTH);
            if (max != null) max.setBaseValue(hp);
            w.setHealth(hp);
            AttributeInstance dmg = w.getAttribute(Attribute.ATTACK_DAMAGE);
            if (dmg != null) dmg.setBaseValue(Math.max(4.0, atk));
            AttributeInstance range = w.getAttribute(Attribute.FOLLOW_RANGE);
            if (range != null) range.setBaseValue(64.0);
            w.getPersistentDataContainer().set(keyOwner, PersistentDataType.STRING, id.toString());
        });
        active.put(id, pet.getUniqueId());
        modes.put(id, Mode.FOLLOW);
        ensureLabels(pet, t, p.getName(), id);
    }

    // ---------- floating labels (armor stands, work on old clients) ----------
    public void ensureLabels(Wolf wolf, PetType t, String ownerName, UUID owner) {
        List<UUID> ids = labels.get(owner);
        boolean ok = ids != null && ids.size() == 2 && ids.stream().allMatch(i -> {
            Entity e = Bukkit.getEntity(i);
            return e != null && e.isValid();
        });
        if (!ok) {
            removeLabels(owner);
            Component petLine = MiniMessage.miniMessage().deserialize(t.rarity().mini + Fancy.sc(t.name()));
            Component ownerLine = Component.text(ownerName, NamedTextColor.WHITE);
            ids = new ArrayList<>();
            ids.add(makeLabel(wolf, petLine).getUniqueId());
            ids.add(makeLabel(wolf, ownerLine).getUniqueId());
            labels.put(owner, ids);
        }
        Location base = wolf.getLocation();
        moveLabel(ids.get(0), base.clone().add(0, 1.0, 0));
        moveLabel(ids.get(1), base.clone().add(0, 0.72, 0));
    }

    private ArmorStand makeLabel(Wolf wolf, Component text) {
        return wolf.getWorld().spawn(wolf.getLocation(), ArmorStand.class, a -> {
            a.setVisible(false);
            a.setMarker(true);
            a.setSmall(true);
            a.setGravity(false);
            a.setInvulnerable(true);
            a.setPersistent(false);
            a.customName(text);
            a.setCustomNameVisible(true);
        });
    }

    private void moveLabel(UUID id, Location loc) {
        Entity e = Bukkit.getEntity(id);
        if (e != null && (e.getWorld() != loc.getWorld() || e.getLocation().distanceSquared(loc) > 0.0025)) e.teleport(loc);
    }

    public void removeLabels(UUID owner) {
        List<UUID> ids = labels.remove(owner);
        if (ids == null) return;
        for (UUID i : ids) {
            Entity e = Bukkit.getEntity(i);
            if (e != null) e.remove();
        }
    }

    public void startLabelTask() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (UUID owner : activeOwners()) {
                Wolf w = getWolf(owner);
                Player p = Bukkit.getPlayer(owner);
                PetType t = getPet(owner);
                if (w != null && p != null && t != null) ensureLabels(w, t, p.getName(), owner);
                else removeLabels(owner);
            }
        }, 20L, 1L);
    }

    // ---------- despawn ----------
    public void despawn(UUID owner) {
        removeLabels(owner);
        UUID eid = active.remove(owner);
        if (eid == null) return;
        Entity e = Bukkit.getEntity(eid);
        if (e != null) e.remove();
    }

    public void despawnAll() {
        for (UUID owner : new ArrayList<>(active.keySet())) despawn(owner);
    }

    // ---------- revive ----------
    public void giveToken(Player p) {
        ItemStack item = new ItemStack(Material.NETHER_STAR);
        item.editMeta(m -> {
            m.displayName(Component.text("Revive Token", NamedTextColor.GOLD, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
            m.lore(List.of(Component.text("Right-click the revival altar at spawn", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false)));
            m.getPersistentDataContainer().set(keyToken, PersistentDataType.STRING, p.getUniqueId().toString());
        });
        Map<Integer, ItemStack> left = p.getInventory().addItem(item);
        left.values().forEach(i -> p.getWorld().dropItem(p.getLocation(), i));
        data.set(p.getUniqueId() + ".token", false);
        save();
    }

    public boolean isRevivePoint(Location loc) {
        String world = plugin.getConfig().getString("revive-point.world", "");
        if (world.isEmpty() || loc.getWorld() == null || !loc.getWorld().getName().equals(world)) return false;
        return loc.getBlockX() == plugin.getConfig().getInt("revive-point.x")
                && loc.getBlockY() == plugin.getConfig().getInt("revive-point.y")
                && loc.getBlockZ() == plugin.getConfig().getInt("revive-point.z");
    }
}
