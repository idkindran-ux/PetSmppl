package com.zebrawings.pets;

public record PetType(String id, String name, Rarity rarity) {}
