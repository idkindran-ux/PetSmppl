package com.zebrawings.pets;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.*;

public final class PetRegistry {
    private static final Map<String, PetType> BY_ID = new LinkedHashMap<>();
    private static final Map<Rarity, List<PetType>> BY_RARITY = new EnumMap<>(Rarity.class);
    private static final Random RNG = new Random();

    private PetRegistry() {}

    public static void load(JavaPlugin plugin) {
        File f = new File(plugin.getDataFolder(), "pets.yml");
        if (!f.exists()) plugin.saveResource("pets.yml", false);
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        BY_ID.clear();
        BY_RARITY.clear();
        for (Rarity r : Rarity.values()) {
            BY_RARITY.put(r, new ArrayList<>());
            if (r == Rarity.ADMIN) continue;
            for (String n : cfg.getStringList(r.key)) add(r, n);
        }
        add(Rarity.ADMIN, "Zebra");
        if (BY_RARITY.get(Rarity.COMMON).isEmpty()) add(Rarity.COMMON, "Sparrow");
    }

    private static void add(Rarity r, String name) {
        PetType t = new PetType(name.toLowerCase().replace(' ', '_'), name, r);
        BY_ID.put(t.id(), t);
        BY_RARITY.get(r).add(t);
    }

    public static PetType byId(String id) { return BY_ID.get(id); }

    public static PetType zebra() { return BY_ID.get("zebra"); }

    public static PetType random() {
        double total = 0;
        for (Rarity r : Rarity.values()) {
            if (r != Rarity.ADMIN && !BY_RARITY.get(r).isEmpty()) total += Math.max(0, r.chance);
        }
        if (total <= 0) {
            List<PetType> c = BY_RARITY.get(Rarity.COMMON);
            return c.get(RNG.nextInt(c.size()));
        }
        double roll = RNG.nextDouble() * total;
        for (Rarity r : Rarity.values()) {
            if (r == Rarity.ADMIN || BY_RARITY.get(r).isEmpty()) continue;
            roll -= Math.max(0, r.chance);
            if (roll < 0) {
                List<PetType> list = BY_RARITY.get(r);
                return list.get(RNG.nextInt(list.size()));
            }
        }
        List<PetType> c = BY_RARITY.get(Rarity.COMMON);
        return c.get(RNG.nextInt(c.size()));
    }
}
