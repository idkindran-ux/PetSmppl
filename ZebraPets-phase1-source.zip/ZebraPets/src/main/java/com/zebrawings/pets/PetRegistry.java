package com.zebrawings.pets;

import java.util.*;

public final class PetRegistry {
    private static final Map<String, PetType> BY_ID = new LinkedHashMap<>();
    private static final Map<Rarity, List<PetType>> BY_RARITY = new EnumMap<>(Rarity.class);
    private static final Random RNG = new Random();

    static {
        add(Rarity.COMMON, "Sparrow", "Pigeon", "Duck", "Goose", "Crow", "Mouse", "Hamster", "Squirrel",
                "Hedgehog", "Deer", "Beaver", "Otter", "Raccoon", "Mole", "Gecko", "Lizard", "Toad", "Snail",
                "Butterfly", "Ladybug", "Duckling", "Quail", "Seagull", "Chipmunk", "Ferret", "Guinea Pig",
                "Skunk", "Possum", "Hen", "Lamb");
        add(Rarity.UNCOMMON, "Owl", "Badger", "Hare", "Monkey", "Kangaroo", "Meerkat", "Flamingo", "Peacock",
                "Koala", "Sloth");
        add(Rarity.RARE, "Tiger", "Lion", "Cheetah", "Wolverine", "Red Panda");
        add(Rarity.VERY_RARE, "Snow Leopard", "Eagle", "Gorilla");
        add(Rarity.ULTRA_RARE, "Elephant");
        add(Rarity.ADMIN, "Zebra");
    }

    private PetRegistry() {}

    private static void add(Rarity r, String... names) {
        for (String n : names) {
            PetType t = new PetType(n.toLowerCase().replace(' ', '_'), n, r);
            BY_ID.put(t.id(), t);
            BY_RARITY.computeIfAbsent(r, k -> new ArrayList<>()).add(t);
        }
    }

    public static PetType byId(String id) { return BY_ID.get(id); }

    public static PetType zebra() { return BY_ID.get("zebra"); }

    public static PetType random() {
        int total = 0;
        for (Rarity r : Rarity.values()) total += r.weight;
        int roll = RNG.nextInt(total);
        for (Rarity r : Rarity.values()) {
            roll -= r.weight;
            if (roll < 0) {
                List<PetType> list = BY_RARITY.get(r);
                return list.get(RNG.nextInt(list.size()));
            }
        }
        return BY_RARITY.get(Rarity.COMMON).get(0);
    }
}
