package com.zebrawings.pets;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Wolf;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.UUID;

public class PetListener implements Listener {
    private final ZebraPets plugin;
    private final PetManager pets;
    private final PetTasks tasks;
    private final PetChat chat;

    public PetListener(ZebraPets plugin, PetManager pets, PetTasks tasks, PetChat chat) {
        this.plugin = plugin;
        this.pets = pets;
        this.tasks = tasks;
        this.chat = chat;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> pets.ensureAndSpawn(p), 20L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        tasks.cleanup(p);
        chat.forget(p.getUniqueId());
        pets.despawn(p.getUniqueId());
    }

    @EventHandler
    public void onPetDeath(EntityDeathEvent e) {
        if (!(e.getEntity() instanceof Wolf w)) return;
        String owner = w.getPersistentDataContainer().get(pets.keyOwner, PersistentDataType.STRING);
        if (owner == null) return;
        e.getDrops().clear();
        e.setDroppedExp(0);
        UUID id = UUID.fromString(owner);
        pets.markDead(id);
        pets.removeLabels(id);
        tasks.cancelJob(id);
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
            p.sendMessage(Component.text("Your pet died! You received a Revive Token.", NamedTextColor.RED));
            pets.giveToken(p);
        }
    }

    @EventHandler
    public void onOwnerHitsPet(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Wolf w)) return;
        String owner = w.getPersistentDataContainer().get(pets.keyOwner, PersistentDataType.STRING);
        if (owner == null) return;
        Entity damager = e.getDamager();
        if (damager instanceof Projectile pr && pr.getShooter() instanceof Entity sh) damager = sh;
        if (damager.getUniqueId().toString().equals(owner)) e.setCancelled(true);
    }

    @EventHandler
    public void onAltarBreak(BlockBreakEvent e) {
        if (pets.isRevivePoint(e.getBlock().getLocation()) && !e.getPlayer().hasPermission("zebrapets.admin")) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onRevive(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        if (e.getClickedBlock() == null) return;
        Location loc = e.getClickedBlock().getLocation();
        if (!pets.isRevivePoint(loc)) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir() || !hand.hasItemMeta()) {
            p.sendMessage(Component.text("Hold your Revive Token to revive your pet.", NamedTextColor.GRAY));
            return;
        }
        String tokenOwner = hand.getItemMeta().getPersistentDataContainer().get(pets.keyToken, PersistentDataType.STRING);
        if (tokenOwner == null) return;
        if (!tokenOwner.equals(p.getUniqueId().toString())) {
            p.sendMessage(Component.text("This token belongs to someone else.", NamedTextColor.RED));
            return;
        }
        if (!pets.isDead(p.getUniqueId())) {
            p.sendMessage(Component.text("Your pet is alive.", NamedTextColor.RED));
            return;
        }
        double cost = plugin.getConfig().getDouble("revive-cost", 3000000);
        if (!plugin.economy().has(p, cost)) {
            p.sendMessage(Component.text("You need $" + String.format("%,.0f", cost) + " to revive your pet.", NamedTextColor.RED));
            return;
        }
        plugin.economy().withdrawPlayer(p, cost);
        hand.setAmount(hand.getAmount() - 1);
        pets.revive(p);
        p.sendMessage(Component.text("Your pet has been revived!", NamedTextColor.GREEN));
    }
}
